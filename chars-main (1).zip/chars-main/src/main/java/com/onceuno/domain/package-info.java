/**
 * JPA domain objects.
 */
package com.onceuno.domain;
