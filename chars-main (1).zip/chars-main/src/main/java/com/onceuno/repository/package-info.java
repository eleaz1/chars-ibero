/**
 * Spring Data JPA repositories.
 */
package com.onceuno.repository;
