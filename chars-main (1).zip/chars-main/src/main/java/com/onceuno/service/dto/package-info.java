/**
 * Data Transfer Objects.
 */
package com.onceuno.service.dto;
