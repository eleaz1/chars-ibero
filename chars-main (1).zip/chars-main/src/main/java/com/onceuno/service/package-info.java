/**
 * Service layer beans.
 */
package com.onceuno.service;
