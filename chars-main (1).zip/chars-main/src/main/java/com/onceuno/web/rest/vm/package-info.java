/**
 * View Models used by Spring MVC REST controllers.
 */
package com.onceuno.web.rest.vm;
